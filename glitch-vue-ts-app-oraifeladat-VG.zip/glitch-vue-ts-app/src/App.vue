<template>

  <GlitchText text="Glitch animáció TS-sel" />

</template>

<script lang="ts" setup>

import GlitchText from './components/GlitchText.vue'

</script>
