<template>
  <div>
    <h1 class="text-4xl font-bold text-blue-600 mb-4">Kapcsolat</h1>
    <p class="text-gray-700 text-lg mb-6">Itt találod a kapcsolatfelvételi információkat.</p>
  </div>
</template>

<script>
export default {
  name: 'Contact',
}
</script>