<template>
<div>
<h1 class="text-4xl font-bold text-blue-600 mb-4">Hello</h1>
<p class="text-gray-700 text-lg mb-6">Üdvözöllek az oldalon!</p>
</div>
</template>
<script>
export default {
name: 'Hello',
}
</script>