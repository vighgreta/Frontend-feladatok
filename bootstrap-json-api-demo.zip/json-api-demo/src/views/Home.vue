<template>
  <div class="text-center mt-5">
    <h1 class="fw-bold">Üdvözöllek a Főoldalon!</h1>
    <p class="text-muted mt-2">
      Ez egy generikus Vue + json-server példa.
    </p>
  </div>
</template>
