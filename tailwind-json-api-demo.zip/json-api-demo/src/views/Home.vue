<template>

  <div class="p-6 text-center">

    <h1 class="text-3xl font-bold mb-2">Üdvözöllek a Főoldalon!</h1>

    <p class="text-gray-700">

      Ez egy generikus Vue + json-server példa alkalmazás.

    </p>

  </div>

</template>

