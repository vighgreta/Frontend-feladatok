<template>
  <div>
    <h1>Kapcsolat</h1>
    <p>Itt találod a kapcsolatfelvételi információkat.</p>
  </div>
</template>

<script>
export default {
  name: 'Contact',
}
</script>