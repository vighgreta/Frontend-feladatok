<template>
<div>
<h1>Hello</h1>
<p>Üdvözöllek az oldalon!</p>
</div>
</template>
<script>
export default {
name: 'Hello',
}
</script>