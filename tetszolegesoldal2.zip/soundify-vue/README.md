# Vue 3 + Vite

This template should help get you started developing with Vue 3 in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

Learn more about IDE Support for Vue in the [Vue Docs Scaling up Guide](https://vuejs.org/guide/scaling-up/tooling.html#ide-support).

Spotifyhoz hasonló Soundify projekt munkafolyamatai:
16:05 - Elkezdtem a projektet, létrehoztam a hiányzó mappákat és fájlokat
16:30 - Végeztem a kódok beírásásval a Claude.ai segítségével
16:47 - Hibák javítási folyamata (A HelloWorld.vue-t szeretné betöltetni futtatáskor, viszont nincs megjelenítve sehol sem a HelloWorld.vue + törölve is van mindenhonnan. Futtatáskor ugyanúgy megjelenik mint hiányzó "alkatrész")
17:17 - Elment az áram, a munkafolyamatok megállnak
20:00-20:20 - A hiba kijavítva, működő oldal kész
20:39 - utólag vettem észre hogy a feladatból hiányzik az amit Tanár Úr tetszett írni, így azt is elkészítem
20:40 - hiányzó részek pótlása


Elindítási mód: 
        npm install
        npm install lucide-vue-next
        npm run dev