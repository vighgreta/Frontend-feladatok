# Vue 3 + Vite

This template should help get you started developing with Vue 3 in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

Learn more about IDE Support for Vue in the [Vue Docs Scaling up Guide](https://vuejs.org/guide/scaling-up/tooling.html#ide-support).



2025.11.22. Javítás
Az eddigi folyamatokat feltúrbóztam egy kis AI segítséggel. Új fájéok kerültek a projektbe és új design ami nagyon feldobja az oldalt.
21:08 - új fájlok és mappák létrehozása és kódok megírása

A projekt elindítása:
    npm install
    npm install lucide-vue-next
    npm install -D tailwindcss@^3.4.0 postcss autoprefixer
    npx tailwindcss init -p